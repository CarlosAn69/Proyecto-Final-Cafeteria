from django.contrib import admin
from .models import Cafeteria, Empleado, Cliente, Producto, Pedido, DetallePedido

admin.site.register(Cafeteria)
admin.site.register(Empleado)
admin.site.register(Cliente)
admin.site.register(Producto)
admin.site.register(Pedido)
admin.site.register(DetallePedido)
