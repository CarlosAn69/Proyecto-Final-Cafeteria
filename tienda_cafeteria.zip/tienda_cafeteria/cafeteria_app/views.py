from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST
from .models import Producto, Cliente, Empleado, Pedido, DetallePedido
from .forms import ProductoForm  # Importar el formulario nuevo

def home(request):
    productos = Producto.objects.all()
    return render(request, 'cafeteria_app/home.html', {'productos': productos})

def agregar_al_carrito(request, producto_id):
    carrito = request.session.get('carrito', {})
    carrito[str(producto_id)] = carrito.get(str(producto_id), 0) + 1
    request.session['carrito'] = carrito
    return redirect('home')

def mostrar_carrito(request):
    carrito = request.session.get('carrito', {})
    productos = []
    total = 0
    for id_str, cantidad in carrito.items():
        prod = get_object_or_404(Producto, id=int(id_str))
        subtotal = prod.precio * cantidad
        productos.append({'producto': prod, 'cantidad': cantidad, 'subtotal': subtotal})
        total += subtotal
    return render(request, 'cafeteria_app/carrito.html', {'productos': productos, 'total': total})

def quitar_del_carrito(request, producto_id):
    carrito = request.session.get('carrito', {})
    if str(producto_id) in carrito:
        del carrito[str(producto_id)]
        request.session['carrito'] = carrito
    return redirect('mostrar_carrito')

@require_POST
def actualizar_cantidad(request, producto_id):
    accion = request.POST.get('accion')
    carrito = request.session.get('carrito', {})
    pid = str(producto_id)

    if pid in carrito:
        if accion == 'mas':
            carrito[pid] += 1
        elif accion == 'menos':
            carrito[pid] -= 1
            if carrito[pid] < 1:
                del carrito[pid]

    request.session['carrito'] = carrito
    return redirect('mostrar_carrito')

def colocar_pedido(request):
    carrito = request.session.get('carrito', {})
    if not carrito:
        return redirect('home')

    cliente = Cliente.objects.first()
    if not cliente:
        # Si no hay clientes, evitar error redirigiendo o mostrar mensaje
        return redirect('home')

    empleado = Empleado.objects.first()
    if not empleado:
        return redirect('home')

    pedido = Pedido.objects.create(cliente=cliente, empleado=empleado, estatus='pendiente', total=0)

    total = 0
    for id_str, cantidad in carrito.items():
        prod = Producto.objects.get(id=int(id_str))
        subtotal = prod.precio * cantidad
        DetallePedido.objects.create(pedido=pedido, producto=prod, cantidad=cantidad, subtotal=subtotal)
        total += subtotal

    pedido.total = total
    pedido.save()

    # Limpiar carrito después del pedido
    request.session['carrito'] = {}

    return render(request, 'cafeteria_app/pedido_confirmado.html', {'pedido': pedido})

def crear_producto(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = ProductoForm()
    return render(request, 'cafeteria_app/producto_form.html', {'form': form})




