from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # Página principal / catálogo
    path('agregar/<int:producto_id>/', views.agregar_al_carrito, name='agregar_al_carrito'),  # Agregar producto al carrito
    path('carrito/', views.mostrar_carrito, name='mostrar_carrito'),  # Mostrar carrito
    path('quitar/<int:producto_id>/', views.quitar_del_carrito, name='quitar_del_carrito'),  # Quitar producto del carrito
    path('actualizar_cantidad/<int:producto_id>/', views.actualizar_cantidad, name='actualizar_cantidad'),  # Actualizar cantidad producto
    path('colocar_pedido/', views.colocar_pedido, name='colocar_pedido'),  # Finalizar pedido
]
